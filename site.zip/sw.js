/* Offline-first shell, online-only Google services. */
const VERSION = 'school-evidence-pwa-v1.0.0';
const SHELL = ['./','./index.html','./manifest.webmanifest','./assets/styles.css','./assets/fontawesome.css','./assets/qr.js','./assets/noto-arabic.ttf','./assets/webfonts/fa-solid-900.woff2','./assets/webfonts/fa-regular-400.woff2','./assets/webfonts/fa-brands-400.woff2','./icons/icon-192.png','./icons/icon-512.png','./icons/apple-touch-icon.png'];
self.addEventListener('install', e => e.waitUntil(caches.open(VERSION).then(cache => cache.addAll(SHELL))));
self.addEventListener('activate', e => e.waitUntil((async()=>{for(const name of await caches.keys()){if(name.startsWith('school-evidence-pwa-')&&name!==VERSION)await caches.delete(name);}await self.clients.claim();})()));
self.addEventListener('message', e => {if(e.data?.type === 'SKIP_WAITING') self.skipWaiting();});
self.addEventListener('fetch', e => {
 const req=e.request;
 if(req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
 const url=new URL(req.url);
 if(req.mode === 'navigate') {
   e.respondWith(fetch(req).then(res=>{if(res.ok){const copy=res.clone();caches.open(VERSION).then(cache=>cache.put('./index.html', copy)).catch(()=>{});}return res;}).catch(()=>caches.match('./index.html')));
   return;
 }
 e.respondWith(caches.match(req).then(cached=>cached || fetch(req)));
});
