/* Accessible, mobile-only quick navigation; no interference with report/signature canvases. */
(function () {
  'use strict';
  const isSmall = () => window.matchMedia('(max-width:767px)').matches;
  const menu = () => document.getElementById('headerTools');
  const toggle = () => document.getElementById('mobileMenuToggle');
  const backdrop = () => document.getElementById('mobileMenuBackdrop');
  // iOS Safari may ignore viewport scaling limits; suppress page pinch gestures at phone widths.
  document.addEventListener('gesturestart',event=>{if(isSmall())event.preventDefault();},{passive:false});
  document.addEventListener('gesturechange',event=>{if(isSmall())event.preventDefault();},{passive:false});
  window.closeMobileTools = function () {
    document.body.classList.remove('mobile-menu-open');
    toggle()?.setAttribute('aria-expanded', 'false');
    toggle()?.setAttribute('aria-label', 'فتح قائمة الأدوات');
    if (backdrop()) backdrop().hidden = true;
  };
  window.toggleMobileTools = function () {
    if (!isSmall()) return;
    const opening = !document.body.classList.contains('mobile-menu-open');
    if (!opening) return window.closeMobileTools();
    document.body.classList.add('mobile-menu-open');
    toggle()?.setAttribute('aria-expanded', 'true');
    toggle()?.setAttribute('aria-label', 'إغلاق قائمة الأدوات');
    if (backdrop()) backdrop().hidden = false;
  };
  window.mobileNavigate = function (destination) {
    if (destination === 'more') return window.toggleMobileTools();
    window.closeMobileTools();
    if (destination === 'search') {
      const input = document.getElementById('searchInput');
      input?.scrollIntoView({behavior:'smooth',block:'center'});
      input?.focus({preventScroll:true});
    } else if (destination === 'sections') {
      document.getElementById('schoolCategoryTabs')?.scrollIntoView({behavior:'smooth',block:'start'});
    } else {
      window.scrollTo({top:0,behavior:'smooth'});
    }
  };
  const initMobile = ()=>{
    menu()?.addEventListener('click', event=>{
      if (event.target.closest('button:not(#mobileMenuToggle),label')) window.closeMobileTools();
    });
    document.addEventListener('keydown',event=>{
      if (event.key==='Escape'&&document.body.classList.contains('mobile-menu-open')) {
        window.closeMobileTools();toggle()?.focus();
      }
    });
    window.addEventListener('resize',()=>{if(!isSmall())window.closeMobileTools();},{passive:true});
    // Keep the bottom navigation hidden during sign-in, to avoid obscuring form actions.
    const login=document.getElementById('loginScreenOverlay');
    if(login){
      const observer=new MutationObserver(()=>{
        const loggedOut=!login.classList.contains('hidden');
        const nav=document.getElementById('mobileBottomNav');
        if(nav)nav.hidden=loggedOut;
        if(loggedOut)window.closeMobileTools();
      });
      observer.observe(login,{attributes:true,attributeFilter:['class']});
      const nav=document.getElementById('mobileBottomNav');
      if(nav)nav.hidden=!login.classList.contains('hidden');
    }
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initMobile,{once:true});else initMobile();
})();
